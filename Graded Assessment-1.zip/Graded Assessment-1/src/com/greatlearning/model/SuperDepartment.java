package com.greatlearning.model;

public class SuperDepartment {
	String departmentName() {
		return "Super Department" + "\n";
	}
	String getTodaysWork() {
		return "No work as of now" + "\n";
	}
	String getWorkDeadline() {
		return "Nill" + "\n";
	}
	public String isTodayAHoliday() {
		return "Today is not holiday" + "\n";
	}
	}
