package com.greatlearning.service;

public class HrDepartment {
	public String departmentName() {
		return "HR Deaprtment" + "\n";
	}
	public String getTodaysWork() {
		return "Fill today's timesheet and mark your attendance" + "\n";
	}
	public String doActivity() {
		return "team Lunch" + "\n";
	}
	public String getWorkDeadline() {
		return "Complete by EOD" + "\n";
	}
	public String isTodayAHoliday() {
		// TODO Auto-generated method stub
		return null;
	}

}
