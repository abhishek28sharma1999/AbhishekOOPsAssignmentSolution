package com.greatlearning.service;

public class AdminDepartment {
	public String departmentName() {
		return "Admin Department" + "\n";
	}
	public String getTodaysWork() {
		return "Complete your documents submission" + "\n";
	}
	public String getWorkDeadline() {
		return "Complete by EOD" + "\n";
	}
	public String isTodayAHoliday() {
		// TODO Auto-generated method stub
		return null;
	}

}
